#ifndef _MY_HEADERS_H_
#define _MY_HEADERS_H_

#include "type_def.h"
#include "sq_stack.h"
#include "aglorithm.h"

extern SqStack S;
extern Map[SIZE][SIZE]; 
#endif