#include <stdio.h>

#include "alloc.h"

/**
 * �㷨8.1
 */