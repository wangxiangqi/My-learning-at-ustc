#ifndef _ALOGRITHM_H_
#define _ALOGRITHM_H_

int Index_KMP(SString S, SString T, int pos);
void get_next(SString T, int next[]);
void get_nextval(SString, int nextval[]);

#endif s