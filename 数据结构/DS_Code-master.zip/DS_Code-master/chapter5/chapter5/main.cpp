#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

int main()
{

	return 0;
}