#ifndef _TYPE_DEF_H_
#define _TYPE_DEF_H_

#define ERROR -1
#define OK 1

typedef int ElemType;
typedef int Status;

#endif