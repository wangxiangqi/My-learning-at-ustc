#ifndef _PRACTICE_H_
#define _PRACTICE_H_

void RPN(SqStack &S1, SqStack &S2);

#endif