#ifndef _MY_HEADERS_H_
#define _MY_HEADERS_H_

#include "type_def.h"
#include "sq_stack.h"
#include "aglorithm.h"
#include "queue.h"
#include "sq_queue.h"
#include "practice.h"

#endif