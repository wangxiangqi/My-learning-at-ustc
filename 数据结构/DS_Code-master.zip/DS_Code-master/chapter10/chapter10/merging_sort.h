#ifndef _MERGING_SORT_H_
#define _MERGING_SORT_H_

void Merge(int SR[], int TR[], int i, int m, int n);
void MSort(int SR[], int TR1[], int s, int t);
void MergeSort(SqList &L);

#endif