#ifndef _QUICK_SORT_H_
#define _QUICK_SORT_H_

int Partition_a(SqList &L, int low, int high);
int Partition(SqList &L, int low, int high);
void QSort(SqList &L, int low, int high);
void QuickSort(SqList &L);

#endif