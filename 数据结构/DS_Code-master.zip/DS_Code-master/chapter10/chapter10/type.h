#ifndef _TYPE_H_
#define _TYPE_H_

#define OK 1
#define TRUE 1
#define FALSE 0
#define ERROR 0
typedef int Status;
typedef int ElemType;

#endif