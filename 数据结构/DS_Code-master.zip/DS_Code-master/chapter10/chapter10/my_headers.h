
#include "type.h"
#include "sqlist.h"
#include "insert_sort.h"
#include "quick_sort.h"
#include "select_sort.h"
#include "merging_sort.h"
#include "radix_sort.h"