#ifndef _TRIAL_H_
#define _TRIAL_H_

void trial(int i, int n);
void display_chess(int n);
void put(int i, int j);
void remove(int i, int j);
bool isReasonable(int n, int i, int j);

#endif